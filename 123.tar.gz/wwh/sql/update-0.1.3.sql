CREATE TABLE IF NOT EXISTS `redirect` (
  `redirect_path` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `redirect_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

