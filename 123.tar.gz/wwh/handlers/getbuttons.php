<?php

	include('buttons.php'); 
	echo buttons();

?>